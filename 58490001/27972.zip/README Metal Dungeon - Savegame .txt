Save game for Metal Dungeon (US-5849001):

- Main 10 floors beaten (+8 unlocked)
- Party of 5 members (level 163-132)
- Lots of goodies in inventory
- 99% of items discovered in archive
- Not hacked, clean, all characters on Fencer and Analyzer levels (no upgrades, 4 Elemental Orbs still in inventory)

WARNING: Backup your previous savegame before copying, in case of region incompatibility

INSTALLATION: Upload each UDATA and TDATA contents in your default savegame directory 