Blackstone NTSC-US for original XBox 100% Savegame (58490004)
- Main Character maxed out
- All Stages unlocked

Installation:
Extract the contained directory UDATA on your Xbox default savegame directory or enter the UDATA directory of your Xbox and upload/replace the "58490004" folder from the zip file. 
No files were in TDATA so they're not necessary to upload, I guess.
REMINDER: Backup your previous savegame if any, in case of region or console incompatibility.